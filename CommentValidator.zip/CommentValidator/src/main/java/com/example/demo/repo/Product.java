package com.example.demo.repo;

public class Product {

}
