package com.idugalic.apigateway.services.reviews;

import org.springframework.hateoas.Resources;

public class ReviewsResource extends Resources<Review> {

}
