package com.idugalic.apigateway.services.recommendations;

import org.springframework.hateoas.Resources;

public class ProductsResource extends Resources<Product> {

}
