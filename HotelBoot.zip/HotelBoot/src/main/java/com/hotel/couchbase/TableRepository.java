package com.hotel.couchbase;

import java.util.Collection;

import org.springframework.data.couchbase.core.query.N1qlPrimaryIndexed;
import org.springframework.data.couchbase.core.query.ViewIndexed;
import org.springframework.data.repository.CrudRepository;
import com.hotel.couchbase.dao.Table;

@ViewIndexed(designDoc = "table")
@N1qlPrimaryIndexed
public interface TableRepository extends CrudRepository<Table,String>{
	
	Collection<Table> findByType(String type);
}
