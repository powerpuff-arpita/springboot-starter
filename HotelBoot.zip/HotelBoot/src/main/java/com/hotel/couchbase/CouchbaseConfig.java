package com.hotel.couchbase;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.couchbase.config.AbstractCouchbaseConfiguration;
import org.springframework.data.couchbase.repository.config.EnableCouchbaseRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EntityScan(basePackages ="com.hotel.couchbase.dao")
@EnableCouchbaseRepositories(basePackages = "com.hotel.couchbase")
public class CouchbaseConfig extends AbstractCouchbaseConfiguration {

	@Value("${spring.couchbase.bucket.name}")
	private String bucketName;

	@Value("${spring.couchbase.bucket.password}")
	private String password;

	@Value("${spring.couchbase.bootstrap-hosts}")
	private String ip;

	
	@Override
	protected String getBucketName() {
		return this.bucketName;
	}

	@Override
	protected String getBucketPassword() {
		return "";//this.password;
	}

	@Override
	protected List<String> getBootstrapHosts() {
		// TODO Auto-generated method stub
		return Arrays.asList(this.ip);
	}
}