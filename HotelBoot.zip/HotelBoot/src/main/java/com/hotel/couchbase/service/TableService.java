package com.hotel.couchbase.service;

import java.util.List;

import com.hotel.couchbase.dao.Table;

public interface TableService {

	Table updateStatus(Table table);
	List<Table> getAllTables(String type);
	Table getTableById(String id);
	Table createTable(Table table);
}
