package com.hotel.couchbase.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotel.couchbase.TableRepository;
import com.hotel.couchbase.dao.Table;

@Service
public class TableServiceImpl implements TableService{
	//private final CouchbaseTemplate couchbaseTemplate;
	@Autowired
	private TableRepository tableRepository;

	
	

	@Override
	public Table updateStatus(Table table) {
		// TODO Auto-generated method stub
		if(tableRepository.exists(table.getId())) return tableRepository.save(table);
		else return null;
	}

	@Override
	public List<Table> getAllTables(String type) {
		// TODO Auto-generated method stub
		return (List<Table>)tableRepository.findByType(type);
	}

	@Override
	public Table getTableById(String id) {
		// TODO Auto-generated method stub
		if(tableRepository.exists(id)) return tableRepository.findOne(id);
		else return null;
	}

	@Override
	public Table createTable(Table table) {
		// TODO Auto-generated method stub
		return tableRepository.save(table);
	}

	/*public List<String> search(String query, double lat, double lon, int distance) {
		return facebook.placesOperations().search(query, lat, lon, distance).stream()
				.map(p -> this.placeRepository.save(new Place(p))).map(Place::getId)
				.collect(Collectors.toList());
	
	}*/
}
