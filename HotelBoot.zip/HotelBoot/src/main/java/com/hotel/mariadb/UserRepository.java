package com.hotel.mariadb;

import org.springframework.data.repository.CrudRepository;

import com.hotel.mariadb.dao.User;

public interface UserRepository extends CrudRepository<User, Integer> {
    User findByName(String name);
}